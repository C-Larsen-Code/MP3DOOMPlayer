
#include <stdint.h>

#define POWERUP_BITS_PER_SAMPLE 8
#define POWERUP_SAMPLE_RATE 24000
#define POWERUP_SAMPLES 30239

extern const uint8_t powerUp[POWERUP_SAMPLES];
