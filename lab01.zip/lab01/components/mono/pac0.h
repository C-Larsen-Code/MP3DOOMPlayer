
#include <stdint.h>

#define PAC0_BITS_PER_PIXEL 1
#define PAC0_LENGTH 128
#define PAC0_W 32
#define PAC0_H 32

extern const uint8_t pac0[PAC0_LENGTH];
