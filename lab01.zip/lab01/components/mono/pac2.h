
#include <stdint.h>

#define PAC2_BITS_PER_PIXEL 1
#define PAC2_LENGTH 128
#define PAC2_W 32
#define PAC2_H 32

extern const uint8_t pac2[PAC2_LENGTH];
