
#include <stdint.h>

#define PAC1_BITS_PER_PIXEL 1
#define PAC1_LENGTH 128
#define PAC1_W 32
#define PAC1_H 32

extern const uint8_t pac1[PAC1_LENGTH];
