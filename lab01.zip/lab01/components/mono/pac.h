
#include <stdint.h>

#define PAC_SPRITES 3
#define PAC_BITS_PER_PIXEL 1
#define PAC_LENGTH 128
#define PAC_W 32
#define PAC_H 32

extern const uint8_t *pac[PAC_SPRITES];
