#ifndef HW_H_
#define HW_H_

#if defined(HW_TARGET_LTAG)
#include "hw_ltag.h"
#else
#include "hw_gc.h"
#endif

#endif // HW_H_
