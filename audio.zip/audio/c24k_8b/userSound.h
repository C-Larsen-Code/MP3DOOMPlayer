
#include <stdint.h>

#define USERSOUND_BITS_PER_SAMPLE 8
#define USERSOUND_SAMPLE_RATE 24000
#define USERSOUND_SAMPLES 183597

extern const uint8_t userSound[USERSOUND_SAMPLES];
